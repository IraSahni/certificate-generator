package com.certificate.generator.service;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.certificate.generator.entity.Employee;

@Service
public class ExcelService {

    public List<Employee> parseExcelFile(MultipartFile file) throws IOException {
        List<Employee> employees = new ArrayList<>();
        try (InputStream inputStream = file.getInputStream();
             Workbook workbook = WorkbookFactory.create(inputStream)) {
            Sheet sheet = workbook.getSheetAt(0);
            for (Row row : sheet) {
                // Skip header row
                if (row.getRowNum() == 0) continue; 

                Employee employee = new Employee();

                // Use Cell.getStringCellValue() safely
                Cell nameCell = row.getCell(0);
                Cell emailCell = row.getCell(1);
                Cell departmentCell = row.getCell(2);

                if (nameCell != null) {
                    employee.setName(nameCell.getStringCellValue());
                }
                if (emailCell != null) {
                    employee.setEmail(emailCell.getStringCellValue());
                }
                if (departmentCell != null) {
                    employee.setDepartment(departmentCell.getStringCellValue());
                }

                employees.add(employee);
            }
        } catch (Exception e) {
            throw new IOException("Failed to parse Excel file", e);
        }
        return employees;
    }
}
