package com.certificate.generator.service;

import java.io.File;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import com.certificate.generator.entity.Employee;

import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;

@Service
public class EmailService {

    @Autowired
    private JavaMailSender mailSender;

    public void sendCertificate(Employee employee, File certificateFile) throws MessagingException {
        MimeMessage mimeMessage = mailSender.createMimeMessage();
        MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true);
        helper.setTo(employee.getEmail());
        helper.setSubject("Your Certificate");
        helper.setText("Please find attached your certificate.");

        // Attach the certificate file
        helper.addAttachment("certificate.pdf", certificateFile);

        // Send the email
        mailSender.send(mimeMessage);
    }
}
