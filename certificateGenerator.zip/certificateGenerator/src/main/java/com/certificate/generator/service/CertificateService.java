package com.certificate.generator.service;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.springframework.stereotype.Service;

import com.certificate.generator.entity.Employee;

@Service
public class CertificateService {

    // Path where generated certificates will be saved
    private static final String GENERATED_CERTIFICATE_PATH = "path/to/generated/certificate/";

    public File generateCertificate(Employee employee, File template) throws IOException {
        // Load the template PDF file
        PDDocument document = PDDocument.load(template);

        // Get the first page of the template
        PDPage page = document.getPage(0);

        // Create a content stream to add text to the template
        PDPageContentStream contentStream = new PDPageContentStream(document, page, PDPageContentStream.AppendMode.APPEND, true, true);

        // Set the font and font size for the content
        contentStream.setFont(PDType1Font.HELVETICA_BOLD, 18);

        // Add the employee name at a specific position on the PDF (x, y coordinates)
        contentStream.beginText();
        contentStream.newLineAtOffset(200, 600);  // Adjust coordinates based on your template
        contentStream.showText("Employee Name: " + employee.getName());
        contentStream.endText();

        // Add more text for other employee details (e.g., department)
        contentStream.beginText();
        contentStream.newLineAtOffset(200, 570);  // Adjust coordinates as necessary
        contentStream.showText("Department: " + employee.getDepartment());
        contentStream.endText();

        // Close the content stream
        contentStream.close();

        // Save the modified document as a new file
        File outputFile = new File(GENERATED_CERTIFICATE_PATH + employee.getName() + "_certificate.pdf");
        document.save(outputFile);

        // Close the document
        document.close();

        // Return the path to the generated certificate
        return outputFile;
    }
}
