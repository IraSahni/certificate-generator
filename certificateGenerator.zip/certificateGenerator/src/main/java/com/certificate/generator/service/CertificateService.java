package com.certificate.generator.service;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.springframework.stereotype.Service;

import com.certificate.generator.entity.Employee;

@Service
public class CertificateService {

    private static final String GENERATED_CERTIFICATE_PATH = "path/to/generated/certificate/";

    public File generateCertificate(Employee employee, InputStream templateInputStream) throws IOException {
       
        PDDocument document = PDDocument.load(templateInputStream);

        PDPage page = document.getPage(0);

        PDPageContentStream contentStream = new PDPageContentStream(document, page, PDPageContentStream.AppendMode.APPEND, true, true);

        contentStream.setFont(PDType1Font.HELVETICA_BOLD, 18);

        contentStream.beginText();
        contentStream.newLineAtOffset(200, 600);  
        contentStream.showText("Employee Name: " + employee.getName());
        contentStream.endText();

        contentStream.beginText();
        contentStream.newLineAtOffset(200, 570);  
        contentStream.showText("Department: " + employee.getDepartment());
        contentStream.endText();

        contentStream.close();

        File outputFile = new File(GENERATED_CERTIFICATE_PATH + employee.getName() + "_certificate.pdf");
        document.save(outputFile);

        document.close();

        return outputFile;
    }
}
