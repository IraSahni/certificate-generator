package com.certificate.generator.controller;

import java.io.File;
import java.io.InputStream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.certificate.generator.entity.Employee;
import com.certificate.generator.service.CertificateService;
import com.certificate.generator.service.EmployeeService;

@RestController
public class CertificateController {

    @Autowired
    private CertificateService certificateService;

    @Autowired
    private EmployeeService employeeService;

    @PostMapping("/generate-certificate")
    public ResponseEntity<String> generateCertificate(@RequestParam("employeeId") Long employeeId,
                                                      @RequestParam("template") MultipartFile templateFile) {
        try {
            // Fetch employee details by ID
            Employee employee = employeeService.getEmployeeById(employeeId);
            if (employee == null) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Employee not found");
            }

            // Get the input stream from the uploaded template file
            InputStream templateInputStream = templateFile.getInputStream();

            // Generate certificate using the input stream and employee data
            File certificate = certificateService.generateCertificate(employee, templateInputStream);

            // Return the certificate file path or confirmation message
            return ResponseEntity.ok("Certificate generated successfully: " + certificate.getAbsolutePath());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error generating certificate: " + e.getMessage());
        }
    }
}
