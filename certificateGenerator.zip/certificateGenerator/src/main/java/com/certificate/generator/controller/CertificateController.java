package com.certificate.generator.controller;

import java.io.File;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.certificate.generator.entity.Employee;
import com.certificate.generator.service.CertificateService;
import com.certificate.generator.service.EmployeeService;

@RestController
public class CertificateController {

	@Autowired
	private CertificateService certificateService;

	@Autowired
	private EmployeeService employeeService;

	@PostMapping("/generate-certificate")
	public ResponseEntity<String> generateCertificate(@RequestParam("employeeId") Long employeeId,
			@RequestParam("template") MultipartFile templateFile) {
		try {

			Employee employee = employeeService.getEmployeeById(employeeId);

			File template = new File(templateFile.getOriginalFilename());
			templateFile.transferTo(template);

			File certificate = certificateService.generateCertificate(employee, template);

			return ResponseEntity.ok("Certificate generated: " + certificate.getAbsolutePath());
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body("Error generating certificate: " + e.getMessage());
		}
	}
}
